//CommentList.js
import React, {Component} from 'react';
import CommentBox from './containers/CommentBox';
import style from './style';

class CommentList extends Component {
  render() {
    return (
      <CommentBox />
    )
  }
}
export default CommentList;
